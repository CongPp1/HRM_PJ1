package com.phenikaa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
